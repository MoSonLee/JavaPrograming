import java.util.Scanner;

public class TaxCalculator {

	public static void main(String[] args) {
		
		final double TAX_RATE_LOW = 15.0/100.0;
		final double TAX_RATE_MID = 24.0/100.0;
		final double TAX_RATE_HIGH = 35.0/100.0;
		Scanner input = new Scanner(System.in);
		
		System.out.print("소득은? 만원 단위로 입력하세요. ");
		int income = input.nextInt();
		
		double tax;
		// 아래 코드를 입력하시오.
		
		if(income<=4600) {
			tax = income * TAX_RATE_LOW;
		}
		else if(income>4600 && income<=8800) {
			tax = 4600 * TAX_RATE_LOW + (income-4600)* TAX_RATE_MID;
		}
		else
			tax = 4600 * TAX_RATE_LOW + (4200)* TAX_RATE_MID + (income - 8800) * TAX_RATE_HIGH; 
		
		
		
		
		
		System.out.println("소득세 = " + tax + "만원");
		
		input.close();
			
	}
}
