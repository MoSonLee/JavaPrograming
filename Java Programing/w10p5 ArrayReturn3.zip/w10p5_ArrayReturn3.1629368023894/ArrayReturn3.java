import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 * 배열을 반환하는 메소드를 이용하는 문제
 * 두 개의 배열을 더한다.
 */

public class ArrayReturn3 {

	public static void main(String[] args) throws FileNotFoundException {

        Scanner scanner = new Scanner(System.in);
        
        int seed = scanner.nextInt();
        Random generator = new Random(seed);

        int array1[] = new int[10];
        int array2[] = new int[10];
        int array3[] = new int[10];
        for(int i=0; i<10; i++){
            array1[i] = generator.nextInt(100);
        }
        for(int i=0; i<10; i++){
            array2[i] = generator.nextInt(100);
        }
        array3 = addArrays(array1, array2);

				System.out.print("Seed: ");
        System.out.println(Arrays.toString(array1));
        System.out.println(Arrays.toString(array2));
        System.out.println(Arrays.toString(array3));
        
	}

	/**
	 * 배열 a1과 a2를 더한다.
	 * 전제조건: a1과 a2의 크기는 같다.
	 * a1, a2와 크기가 같은 새 배열을 구성하고
	 * 이 배열에 a1과 a2를 더한 결과를 저장한 후
	 * 새 배열을 가리키는 참조를 반환한다.
	 * @param a1 배열
	 * @param a2 배열
	 * @return a1 + a2 결과를 저장한 새 배열 (정확히는, 새 배열을 가리키는 참조)
	 */
	public static int[] addArrays(int[] a1, int[] a2) 
	{
        int array3[] = new int[10];
		for(int i=0; i<10; i++){
            array3[i] = a1[i] + a2[i];
        }
        return array3;

	}

}