public class CelciusToFarenheit {
 
	public static void main(String[] args) {
     
		// 코드 작성
        for(int i =-40; i<=100;i+=5){
            convertAndPrint(i);
            
        }
		
		}

	/**
	 *  알맞은 설명을 추가하시오!
	 * 섭씨 온도를 화씨 온도로 바꾸고 출력값에 맞게 섭씨 온도, 화씨 온도를 둘 다 출력하는 함수 convertAndPrint입니다.
	 * 
	 * 
	 */
	public static void convertAndPrint(int c) {
		// 코드 작성
        
        System.out.println("C = " + c + " --> " + (c * 9.0/5.0 +32.0));
      
		
	}
}
