import java.util.*;

public class Indexer {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String str1 = input.nextLine();
        int sum= 0;
       
		//  complete the code
		
		str1 = str1.toLowerCase();
		char abc[] = {'a', 'b', 'c'};

		for(int i=0; i < 3; i++){
            int temp = -1;
            for(int x =0; x<str1.length();x++){
                if(str1.charAt(x)==abc[i]){
                    temp = x;
                    break;
                }

            }
            sum += temp;

        }
		
		
		System.out.println(sum);
		input.close();
	}
}
