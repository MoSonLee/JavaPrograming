
import java.util.Scanner;



public class ATMMachine {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		double balance = 5000.0;		// 초기 잔액
		boolean done = false;			// 완료
        
    System.out.println();
        while(true){

            System.out.println("ATM 프로그램입니다. 번호를 입력하세요.");
            System.out.println("잔액 확인: \t1");
            System.out.println("현금 인출: \t2");
            System.out.println("입금: \t\t3");
            System.out.println("종료: \t\t4");
            System.out.print("번호 선택: ");

            int num = input.nextInt();

            if(num==1){
                System.out.println("잔액은 " + balance + "원입니다.");
								System.out.println();
            }
            else if(num==2){
                System.out.print("얼마를 인출하시겠습니까? ");
                int outMoney = input.nextInt();
                if(outMoney> balance){
                    System.out.println("돈이 모자랍니다.");
                    System.out.println("잔액은 " + balance + "원입니다.");
										System.out.println();
                }
                else{
										System.out.println("돈을 받으세요.");
										balance = balance-outMoney;
                    System.out.println("잔액은 " + balance +"원입니다." );
										System.out.println();
                }
                
            }
            else if(num==3){
                System.out.print("금액은? ");
                int inMoney = input.nextInt();
								balance = balance+inMoney;
                System.out.println("잔액은 " + balance +"원입니다." );
								System.out.println();
            }
            else if(num ==4){
                System.out.println("감사합니다.");
                break;
            }
            else{
                System.out.println("올바르지 않은 번호입니다.");
								System.out.println();
            }
        
        }
		
		
	

    }

	}


