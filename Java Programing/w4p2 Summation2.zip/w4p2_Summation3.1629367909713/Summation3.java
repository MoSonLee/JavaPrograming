import java.util.Scanner;

class Summation3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.print("1부터 얼마까지의 짝수를 더하시겠습니까? ");
		int n = input.nextInt();

		int sum = 0;
		int i;
		
		// 방법 1

        for(i =2; i <=n;i+=2){
            sum+=i;
        }
		
		
				
		System.out.println("첫 방법: 1부터 " + n + "까지의 짝수의 합 = " + sum);

        i =1;
        sum=0;
		
		// 방법 2
		for(i =1; i<=n; i++){
            if(i%2==0){
                sum+=i;
            }
            else{
                
            }
        }
		
		
		
		System.out.println("두 번째 방법: 1부터 " + n + "까지의 짝수의 합 = " + sum);

		input.close();
	}
}