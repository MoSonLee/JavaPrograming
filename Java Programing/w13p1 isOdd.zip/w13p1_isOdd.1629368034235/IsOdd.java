//package week13;

import java.util.Scanner;
import java.util.*;

public class IsOdd{
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("32-bit integer: ");
		int input = scan.nextInt();		
	
		System.out.printf("Is %d odd? %b", input, isOdd(input));		
		scan.close();		

	}

 /** isOdd
	* 정수 input이 홀수이면 true, 짝수이면 false를 반환한다.
	* @param input
	* @return
	*/
 public static boolean isOdd(int input) {
		// complete the code 

        if((input & 1) == 1){
            return true;
        }
        else
            return false;
	 
	 
	 
 }
}