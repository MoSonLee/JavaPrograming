import java.util.Scanner;

public class Summations {

	public static void main(String[] args) {

       

		System.out.print("얼마 이하의 자연수를 더하시겠습니까? ");
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
        
		// 코드 작성
        System.out.print(n + "이하 자연수의 합 = ");
        System.out.println(sum(n));
        


		in.close();
	}

	/**
	 * 올바른 설명을 추가하시오.
	 * 
	 * 자연수가 아닌 ㅇ보다 작은 수를 입력시 sum의 값에 0을 넣어주고 자연수를 넣을시 그 수까지 더해지는 sum함수 작성
	 * 
	 */
	public static int sum(int upto) {
		// 코드 작성

        int sum=0;
        if(upto<=0){
            sum=0;
        }
		for(int i =1; i <= upto; i++){
            sum+=i;
        }
        
        return sum;
		
		
	}

}

