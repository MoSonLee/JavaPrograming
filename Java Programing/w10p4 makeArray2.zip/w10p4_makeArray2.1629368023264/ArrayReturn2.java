import java.util.Arrays;

/**
 * 배열을 반환하는 메소드를 이용하는 문제
 * 배열을 반환하는 메소드를 호출한 후
 * 반환된 배열의 내용을 출력한다.
 */

public class ArrayReturn2
{

	public static void main(String[] args) 
	{
     
        int[] array;
        array = makeArray();

        System.out.println(Arrays.toString(array));
        System.out.println();
	
	    for(int i=1; i<11;i++){
            array = makeArray(i);
            System.out.println(Arrays.toString(array));
        }
       
	}

	/**
	 * 크기가 10인 int 배열을 구성한 후
	 * 0번 방에는 0*0을,
	 * 1번 방에는 1*1을
	 * ...
	 * 9번 방에는 9*9를 저장하고
	 * 배열을 반환한다.
	 * 배열을 반환한다는 것은 곧 배열을 가리키는 참조(reference)를 반환한다는 말이다.
	 * @return 배열을 가리키는 참조
	 */
	public static int[] makeArray() 
	{
		int array[] = new int[10];
        for(int i=0; i<10;i++){
            array[i] = i*i;
        }

        return array; 
	}

    public static int[] makeArray(int n) 
	{
		int array[] = new int[n];
        for(int i=0; i<n; i++){
            array[i] = i*i;
        }
        return array;
	}
    

}
