//package week13;

import java.util.Scanner;

public class BitCount {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("32-bit integer: ");
		int input = scan.nextInt();
		int count = bitCount(input);
		System.out.printf("%d has %d number of '1's", input, count);
		scan.close();

	}

	/** bitCount
	* 정수 input을 입력으로 받아 32비트 표현형에서 1의 개수를 세어 반환한다.
	* @param input
	* @return count
	*/
	public static int bitCount(int input) {

        int count =0;
		// complete the code
		while(input!=0){
           

            int A = input&1;
            if((A & 1) ==1)
                count++;
            input = input>>>1;
		
		
		
		
		}
		return count;
	}
}