public class Summations2 {

	public static void main(String[] args) {
		int from, to;
        for(int i=10; i<=90;i+=10){
            from=i;
            to=from+10;
            System.out.println(from + "부터  " + to + "까지의 자연수의 합 = " + sum(from, to));
            
        }
        
		
		
	}

	/**
	 * 알맞은 설명을 넣으시오
	 * 
	 * from부터 to까지의 합을 sum에 넣어주고 sum을 return해주는 sum 함수 구현
	 * 
	 * 
	 */
	public static int sum(int from, int to) {
		// 코드 작성
        int sum=0;
		for(int i = from; i<=to; i++){
            sum+=i;
        }
        return sum;
		
		
		
	}

}
