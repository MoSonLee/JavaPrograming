import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * 
 * int 타입 배열을 만들고 데이터 파일에 있는 정수들을 읽어 배열에 채운다. 
 * 아래와 같은 순서로 배열의 앞에 있는 원소들의 합을 차례로 구해 화면에 출력한다. 
 * 
 * a[0] 
 * a[0] + a[1] 
 * a[0] + a[1] + a[2] 
 * a[0] + a[1] + a[2] + a[3] 
 * ... 
 * 
 */

public class ListSum {
	public static void main(String[] args) throws FileNotFoundException {

		final int SIZE = 100;
		Scanner input = new Scanner(new File("data/integers2.txt"));
		int[] list = new int[SIZE];

		// complete the code
		
		int i = 0;
		while(input.hasNext())
			list[i++] = input.nextInt();
		
		int total = 0;
		for(int j = 0; j<i ; j++){
			total += list[j];
			System.out.println("배열의 첫 " + (j+1) + "개 원소의 합: " + total);
		}
		
		
		
		
		
		
		System.out.println();
		input.close();
	}

}
