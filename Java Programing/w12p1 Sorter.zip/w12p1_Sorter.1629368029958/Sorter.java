import java.util.*;

public class Sorter {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String str1, str2;
		
		// complete the code
		str1 = input.next();
		str2 = input.next();
		
		if(str1.compareTo(str2)>=1)
			System.out.println(str2 +" " + str1);
		else
			System.out.println(str1 +" "+ str2);
		
		
		
		
	}
}
