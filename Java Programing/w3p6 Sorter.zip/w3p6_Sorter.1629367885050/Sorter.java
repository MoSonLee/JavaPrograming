import java.util.Scanner;

public class Sorter {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("세 개의 정수를 입력하세요: ");
		int i = input.nextInt();
		int j = input.nextInt();
		int k = input.nextInt();
		
		// 아래 코드를 완성하시오.
		
		if(i < j && i <k) {
			if(j < k)
				System.out.println(i + " " + j + " " + k);
			else
				System.out.println(i + " " + k + " " + j);
		}
		else if(j < i && j < k) {
			if(i < k)
				System.out.println(j + " " + i + " " + k);
			else
				System.out.println(j + " " + k + " " + i);
		}
		else {
			if(i < j)
				System.out.println(k + " " + i + " " + j);
			else
				System.out.println(k + " " + j + " " + i);
		}
		
		
		input.close();
	}

}
