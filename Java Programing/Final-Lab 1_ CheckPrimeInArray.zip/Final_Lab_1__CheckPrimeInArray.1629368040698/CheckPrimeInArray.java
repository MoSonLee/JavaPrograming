
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;


public class CheckPrimeInArray {
	public static void main(String[] args) {
		
		final int SIZE = 20;
		final int MAX = 100;
		int[] intArray;
		
		Scanner input = new Scanner(System.in);
		System.out.print("Seed: ");
		long seed = input.nextLong();
	
		Random generator = new Random(seed);

		intArray = makeRandomArray(SIZE, MAX, generator);
		System.out.println(Arrays.toString(intArray));	
		
		int count = countPrime(intArray);
		System.out.println(count + " number of primes are in array");	
		
		input.close();
	}
	
	/**
	 * Add comments 
	 makeRandomArray함수에서 generator, scanner를 사용하여 seed에 따라 랜덤한 숫자 20개를 배열에 넣어줍니다.
	 배열 내 인자의 크기는 max보다 작아야하므로 nextInt안에 max를 써주고 배열의 size는 인자로 받아오는 size를 사용해줍니다.
	 * 
	 * 	 
	 */
	public static int[] makeRandomArray(int size, int max, Random generator) {
		// complete the code
		int A[] = new int[size];
		for(int i =0; i< size; i++) {
			A[i] = generator.nextInt(max);
		}
		
		return A;
		
		
	}
	
	/**
	 * Add comments
	 * for문을 돌려 0부터 array 배열의 길이까지 돌리면서 n이 1부터 array[i]까지 array[i]에서 나눴을 때 나머지가 0이면 sum에 1을 더해줍니다.
	 sum 값이 2가 넘어가면 1과 자기 자신 이외에 나눠 떨어지는 숫자가 있는 것이므로 2일때만 return 값인 primeSum에 1을 더해줍니다.
	 * 	 
	 */
	public static int countPrime(int[] array) {
		// complete the code
		int sum =0;
		int primeSum =0;
		
		for(int i = 0; i< array.length; i++) {
			
			sum = 0;
			
			for(int n=1; n<=array[i]; n++) {
				if(array[i] % n == 0 )
					sum+=1;
				
			}
			
			if(sum==2)
				primeSum+=1;
	
			
				
		}
		
		return primeSum;
		
		
		
		
	}	
}
