import java.util.Scanner;

public class EvensSum {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("정해진 구간의 짝수들의 합을 구합니다.");

		boolean done = false;
        
		while (!done) {
			// 코드 작성
			System.out.print("두 개의 정수를 입력하시오: ");
            int from = input.nextInt();
            int to = input.nextInt();
			int temp=0;
      if(from>to){
           temp = from;
           from =to;
           to = temp;
            }

            
			if(from == to){
            
                done = true;
            }
            else{
                System.out.println(from + "부터 "+ to+"까지의 짝수의 합 = " + getEvensSum(from, to));
							System.out.println();
            }
			
			
			
			
			
			
		}

		System.out.print("감사합니다. 프로그램을 마칩니다.");
		input.close();

    }

	/**
	 * 주어진 두 수 사이의 짝수의 합을 구한다. 
	 * 주어진 수가 짝수이면 그 수도 합에 포함시킨다. 
	 * 전제조건: from <= to
	 * 이 메소드를 호출할 때는 이 전제조건을 지켜야 한다.
	 * 메소드를 호출하는 자가 전제조건을 지킬 때만 이 메소드는 올바른 결과를 보장한다.
	 * 
	 * @param from 주어진 수.
	 * @param to 주어진 수.
	 * @return 짝수의 합.
	 */
	
	//from부터 to까지의 짝수의 합을 evenSum에 더해줍니다.
	//짝수인지 판별하기 위해 if문을 사용하여 2로 나눴을떄 나머지를 확인하여 0일 경우에만 더 해줍니다.
	public static int getEvensSum(int from, int to) {
		// 코드 작성
		
	int evenSum =0;
    for(int i =from; i<=to;i++){
        if(i%2==0){
            evenSum+=i;
        }
    }
	return evenSum;
		
		
		
	}
}
