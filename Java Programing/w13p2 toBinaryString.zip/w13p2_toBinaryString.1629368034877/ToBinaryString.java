//package week13;

import java.util.Scanner;

public class ToBinaryString {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("32-bit integer: ");
		int input = scan.nextInt();		
		
		String binaryString1 = toBinaryString(input);
		String binaryString2 = Integer.toBinaryString(input);
			
		System.out.println("ours: " + binaryString1);
		System.out.println("given: " + binaryString2);
		System.out.println("Are these two same?: " + binaryString1.equals(binaryString2));	
		scan.close();		
	}

	/** toBinaryString
	 * 정수 input의 32비트 2의 보수 체계 표현형을 문자열 타입으로 반환한다.
	 * @param input
	 * @return
	 */
	public static String toBinaryString(int input) {
		//complete the code

        StringBuilder sb = new StringBuilder();
        

		while(input!=0){

            int A = input&1;
            sb.append(Integer.toString(A));
            
            input = input>>1;
        }

		sb.reverse();
        return sb.toString();
		
		
		
		
	}
}