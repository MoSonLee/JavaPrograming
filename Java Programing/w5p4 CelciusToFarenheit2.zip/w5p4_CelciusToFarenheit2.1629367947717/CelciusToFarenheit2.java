public class CelciusToFarenheit2 {
 
	public static void main(String[] args) {
     
		// 코드 작성
        for(int i =-40; i<=100;i+=5){
           
            System.out.print("C = " + i + " --> " + convertAndPrint(i));
           
            System.out.println();
           
            
        }
		
		}

	/**
	 *  알맞은 설명을 추가하시오!
	 * 섭씨 온도를 화씨 온도로 바꾸고 출력값에 맞게 섭씨 온도, 화씨 온도를 둘 다 출력하는 함수 convertAndPrint입니다.
	 * 
	 * 
	 */
	public static double convertAndPrint(int c) {
		// 코드 작성
        double f = (c * 9.0/5.0 +32.0);
        return f;
		
	}
}
