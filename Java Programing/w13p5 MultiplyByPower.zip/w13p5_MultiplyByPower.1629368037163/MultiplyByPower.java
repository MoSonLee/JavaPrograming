//package week13;

import java.util.Scanner;

public class MultiplyByPower {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("32-bit integer: ");
		int input = scan.nextInt();		
		System.out.print("to the power of k: ");
		int k = scan.nextInt();		
				
		System.out.printf("%d * 2^%d = %d", input, k, multiplyByPower(input, k));		
		scan.close();		
	}

	/** multiplyByPower
	* 정수 input을 2의 k승으로 곱한 값 반환한다.
	* @param input
	* @param k
	* @return
	*/
	public static int multiplyByPower(int input, int k){
		// complete the code
		
    return input * 2<<(k-1);


	}
}