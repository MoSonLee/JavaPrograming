import java.util.Scanner;

public class StringAdder 
{
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		System.out.print("단어를 두 개 입력하시오: ");
		
		// 아래 코드를 작성하세요.
		
		String a = input.next();
		String b = input.next();
		String addedWord = a + b;
		
		
		
		System.out.println(addedWord);		
		input.close();
	}
}