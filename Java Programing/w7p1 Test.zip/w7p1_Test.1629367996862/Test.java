
class Test{
	public static void main(String[] args){
		Cat myCat = new Cat();
		myCat.print();
		myCat.print();
	}
}

class Cat {
	void print(){
		System.out.println("야옹~");;
		System.out.println("예쁨~");;
	}
}