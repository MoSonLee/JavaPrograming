import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

public class MatrixUtil1
{

	public static void main(String[] args)
	{
        Scanner scanner = new Scanner(System.in);
        System.out.print("Seed: ");
        long seed = scanner.nextLong();

        Random generator = new Random(seed);

        int array[][] = new int [3][5];

        for(int i=0; i<3; i ++){
            for(int j=0; j<5;j++){
                array[i][j] = generator.nextInt(100);  
            }
            
        }
        int array2[] = new int [10];
        
        for(int i=0; i<10;i++){
            array2[i] = generator.nextInt(100);
        }

        printMatrix(array);
        printMatrix2(array2);



	}

	/* 주어진 이차원 배열의 원소를 차례로 출력한다.
	 * @param array 출력할 배열(을 가리키는 참조변수).
	 */
	public static void printMatrix(int[][] array) 
	{
		for(int i=0; i<3; i ++){
            for(int j=0; j<5;j++){
                System.out.print(array[i][j] + "\t");
            }
            System.out.println();
        }

	}
    
    public static void printMatrix2(int[] array2){
        for(int j=0; j<10; j++){
            System.out.print(array2[j] + "\t");
        }
    }
}