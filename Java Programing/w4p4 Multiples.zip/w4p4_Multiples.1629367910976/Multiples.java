import java.util.Scanner;

public class Multiples {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.print("어떤 수의 배수들을 출력할까요? ");
		int n = input.nextInt();
		int i =0;
		int a =1;
		while(n*a<=100){
			i = n*a;
			System.out.print(i + " ");
			a++;
		}
		// 코드 작성
		
		
		
		
		
		input.close();
	}
}