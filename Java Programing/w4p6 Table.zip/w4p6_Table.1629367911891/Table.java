
import java.util.Scanner;

public class Table {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("표를 인쇄합니다.");
		System.out.print("행을 몇 개 만들까요? ");
		int rows = input.nextInt();
		System.out.print("열을 몇 개 만들까요? ");
		int columns = input.nextInt();

		// 코드 작성
		
		for(int i=0; i< rows; i++){
            for(int j=0; j< columns; j++){
                System.out.print("(" + i +", " + j + ")\t");
            }
            System.out.println();
        }
		
		
		

		input.close();
	}
}
