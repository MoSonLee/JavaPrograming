import java.util.Scanner;

public class Digits {

	public static void main (String[] args) {

        Scanner scanner = new Scanner(System.in);
		
        String input = scanner.next();
        System.out.println("숫자를 입력하시오: " + input.length()+"개의 글자로 이루어진 문자열입니다.");
        for(int i=0; i< input.length();i++){
            char c = input.charAt(i);
            System.out.print(c+" ");
        }


		
		
		
		
		
		
		
		
		
	}
}

