import java.util.Scanner;

public class Increase {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("양의 정수를 하나 입력하시오: ");
		int to = input.nextInt();
		
		System.out.println("첫번째 방법");
		
        for(int i=0; i<=to;i++){
       
            System.out.print(i);
            System.out.print("\t");

            if(i%10==9){
                System.out.println();
            }
            
          
        }
		
		
		
		
		System.out.println();
				
		// 두 번째 방법
		
		System.out.println("두번째 방법");
		
        int count =0;
        for(int i=0; i<=to; i++){
            System.out.print(i);
            System.out.print("\t");
            count++;
            if(count==10){
                count =0;
                System.out.println();
            }
        }
		
		
		
		
		
		input.close();
	}
}
