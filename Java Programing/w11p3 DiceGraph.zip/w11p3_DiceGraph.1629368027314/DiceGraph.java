//package week11;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class DiceGraph {

	/**
	 * n개의 주사위를 던져 나온 수를 반환한다.
	 * 주사위는 정육면체 주사위이다.
	 * @param n 주사위 수
	 * @return n개의 주사위를 던져 나온 수
	 */
	public static int castDice(int n, Random generator) {
		int sum = 0;
		for (int i = 0; i < n; i++)
			sum += generator.nextInt(6) + 1;
		return sum;
	}

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.print("Seed: ");
		long seed = input.nextLong();
		Random generator = new Random(seed);

		System.out.print("한 번에 던질 주사위 갯수: ");
		int num_dice = input.nextInt();

		System.out.print("몇 번 던질 것인가: ");
		int trials= input.nextInt();
      
		int[] occurence;	// 각 수가 나온 횟수를 저장하기 위한 배열
		occurence = new int[num_dice*6];
        for(int i =0; i<trials; i++){
            int sum  = 0;
            for(int j=0; j<num_dice; j++){
                sum +=  generator.nextInt(6)+1;
            }
           
            occurence[sum-1] += 1;

        }

        for(int a=num_dice-1;a<occurence.length;a++){
            System.out.println(a+1+ "이 나온 횟수: " + occurence[a]);
        }

        System.out.println();

        for(int a=num_dice-1;a<occurence.length;a++){
            System.out.print(a+1+ ":" + occurence[a]);
            System.out.print("      ");
            for(int i=0; i< occurence[a]; i++){
                System.out.print("*");
            }
            System.out.println();
        }
       
		// occurence 배열 구성
		// 배열의 크기는 num_dice에 따라 달라진다.
		//
		// (예)
		// num_dice가 2일때는 13개의 방(0번부터 12번)을 만들어
		// 0번, 1번은 사용하지 않고 2번부터 12번 방까지 사용한다.
		// (주사위 합이 0, 1인 경우는 없다.)
		// 주사위 합이 2인 횟수는 2번 방에, 3인 횟수는 3번 방에,
		// ... 12인 횟수는 12번 방에 저장한다.
		//
		// num_dice가 3일때는 19개의 방(0번부터 18번)을 만들어
		// 0번, 1번, 2번은 사용하지 않고 3번부터 18번 방까지 사용한다.
		
		//complete the code
		
		
		
		
		
		
		
		input.close();

	}

}
