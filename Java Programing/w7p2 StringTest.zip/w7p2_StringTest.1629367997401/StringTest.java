import java.util.Scanner;

public class StringTest {

	public static void main (String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("문장을 한 줄에 하나씩 두 개 입력하시오.");
		
		String str1 = input.nextLine();
		String str2 = input.nextLine();
		String strTotal = str1.concat(str2);
		// 코드 작성



		System.out.println("첫 문장 길이: " + str1.length());
		System.out.println("두 번째 문장 길이: " + str2.length());
		System.out.println("연결된 새 문자열: " + strTotal);
		System.out.println("마지막 두 글자: " + strTotal.substring(strTotal.length()-2,strTotal.length()));
		System.out.println("첫 글자: " + str1.charAt(0));
		System.out.println("\"" + strTotal.substring(strTotal.length()-2,strTotal.length()) +"\"" + "의 위치: " + strTotal.lastIndexOf(strTotal.substring(strTotal.length()-2,strTotal.length())));

        String s5 = strTotal.replace(strTotal.substring(strTotal.length()-2,strTotal.length()), "###");

        System.out.println(s5);
		
		
		
		
		
		
		
		
		
		
		
		
	}
}

