import java.util.Scanner;

public class Calculator {
	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		System.out.println("사칙 연산을 하는 프로그램입니다.");
		System.out.print("두 수를 차례로 입력하시오: ");
		double x = input.nextDouble();
		double y = input.nextDouble();
		System.out.println("두 수에 어떤 연산을 하시겠습니까?");
		System.out.print("+ - * / 중 하나를 입력하시오: ");
		String operator = input.next();

		double result = 0.0;
		switch (operator) {
		// 아래 코드를 완성하시요.
			case "+":
				result = x+y;
				break;
			case "-":
				result = x-y;
				break;
			case "*":
				result = x*y;
				break;
			case "/":
				result = x/y;
				break;
				
				
				
				
		}

		System.out.printf("%.1f %s %.1f = %.2f", x, operator, y, result);
		System.out.println();
	
		input.close();
	}
}
