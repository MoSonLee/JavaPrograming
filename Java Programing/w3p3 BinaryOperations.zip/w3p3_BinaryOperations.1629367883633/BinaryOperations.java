import java.util.Scanner;

public class BinaryOperations
{
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		Double a = input.nextDouble();
		Double b = input.nextDouble();
		
		System.out.print("실수를 두 개 입력하시오: ");
		
		System.out.printf("%.2f + %.2f = %.2f", a, b, a+b);
		System.out.println();
		System.out.printf("%.2f - %.2f = %.2f", a, b, a-b);
		System.out.println();
		System.out.printf("%.2f * %.2f = %.2f", a, b, a*b);
		System.out.println();
		System.out.printf("%.2f / %.2f = %.2f", a, b, a/b);
		System.out.println();
				
		input.close();
	}
}