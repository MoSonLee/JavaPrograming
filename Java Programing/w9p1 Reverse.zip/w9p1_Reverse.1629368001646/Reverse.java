import java.util.Scanner;

/**
 * 키보드로부터 10개의 정수를 차례로 읽어 배열에 저장한 후 나중 것부터 처음 것까지 차례로 출력한다.
 *
 */
public class Reverse {
	public static void main(String[] args) {
		// 아래 부분을 채워 프로그램을 완성하시오.
		
		Scanner scanner = new Scanner(System.in);
		int list[] = new int[10];
		
		System.out.println("정수 10개를 차례로 입력하시오:");
		for(int i =0; i <10; i++){

			int a = scanner.nextInt();
			list[i]=a;
		}
		
		System.out.println("배열을 역순으로 출력: ");
		for(int i =0; i<10; i++){
			System.out.print(list[9-i] +" ");
		}
		
	}
}
