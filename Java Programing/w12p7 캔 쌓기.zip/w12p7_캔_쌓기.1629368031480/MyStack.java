import java.util.*;

public class MyStack {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String line;

       



		while (input.hasNextLine()) {

			 String[] mystack = new String[100];
    	 int top = -1;
			
			line = input.nextLine();
			String[] lineToken = line.split(" ");
		
			for (int i=0; i<lineToken.length; i++) {
        
	
				
			if(lineToken[i].compareTo("*")==0){
				if(top==-1){
					continue;	
				}
      	 top--;
			}
				else{
          mystack[++top] = lineToken[i];
				}
			
			}
			

        while(top>=0)
            System.out.print(mystack[top--]+ " ");
			
				System.out.println();
        }

    
       

		input.close();
	}
}
